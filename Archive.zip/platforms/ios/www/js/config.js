angular.module('starter.config', [])
.constant('API_URL', 'http://www.urilga.mn:1339')
.constant('GCM_SENDER_ID', '574597432927')
;
